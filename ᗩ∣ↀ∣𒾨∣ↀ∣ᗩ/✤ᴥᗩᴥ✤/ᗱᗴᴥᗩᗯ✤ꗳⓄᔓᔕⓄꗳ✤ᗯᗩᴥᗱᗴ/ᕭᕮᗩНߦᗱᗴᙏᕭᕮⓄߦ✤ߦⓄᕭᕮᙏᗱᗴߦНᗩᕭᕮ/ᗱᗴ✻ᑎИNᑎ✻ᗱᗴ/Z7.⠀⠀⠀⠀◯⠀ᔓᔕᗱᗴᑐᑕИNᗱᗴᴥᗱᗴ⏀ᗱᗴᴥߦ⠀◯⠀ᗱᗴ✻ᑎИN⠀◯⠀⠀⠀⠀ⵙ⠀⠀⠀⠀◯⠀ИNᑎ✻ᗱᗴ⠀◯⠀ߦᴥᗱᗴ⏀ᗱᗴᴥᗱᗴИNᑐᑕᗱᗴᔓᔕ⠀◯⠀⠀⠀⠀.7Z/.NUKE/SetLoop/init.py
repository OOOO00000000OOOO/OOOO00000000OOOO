# load examples folder
nuke.pluginAddPath('./Examples')