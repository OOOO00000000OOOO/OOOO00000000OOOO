# NukeShared - Max van Leeuwen - maxvanleeuwen.com/nukeshared

# This will only redirect Nuke to the 'Required'-path, which is where NukeShared lives.


import nuke
nuke.pluginAddPath('./Required')
nuke.pluginAddPath('./SmoothScrub')
nuke.pluginAddPath('./SetLoop')
#nuke.pluginAddPath('./hagbarth')
#nuke.pluginAddPath('./hagbarth/icons')
#nuke.pluginAddPath('./hagbarth/tools')
#nuke.pluginAddPath('./hagbarth/grapichs')
#nuke.pluginAddPath('./hagbarth/python')
import os
if nuke.NUKE_VERSION_MAJOR < 11:
    os.environ['QT_PREFERRED_BINDING'] ='PySide'
Expression_path = '/Users/ADMINISTRATOR/.nuke/Expression'
nuke.pluginAddPath(Expression_path)
O____O____O = '/Users/ADMINISTRATOR/.nuke/O____O____O'
nuke.pluginAddPath(O____O____O)

## init.py
## loaded by nuke before menu.py

nuke.pluginAddPath('./AP_gizmos') 

nuke.pluginAddPath('./spin_tools') 

#HP tools
nuke.pluginAddPath('./hpTools/icons')
nMajor = nuke.NUKE_VERSION_MAJOR
nMinor = nuke.NUKE_VERSION_MINOR
if nMajor == 12 and nMinor == 0:
    nuke.pluginAddPath('./hpTools/Nuke12.0')
if nMajor == 12 and nMinor == 1:
    nuke.pluginAddPath('./hpTools/Nuke12.1') 