''' Add this to your menu.py '''

##Hagbarth Tools
##toolbar = nuke.toolbar("Nodes")
##m = toolbar.addMenu("Hagbarth Tools", icon="h_tools.png")
##m.addCommand("GradientEditor", "nuke.createNode(\"h_gradienteditor\")", icon="h_gradienteditor.png")

##import ColorGradientUi

import nuke
nuke.pluginAddPath("VP")

toolbar = nuke.menu('Nodes')
toolbar.addMenu('VP', 'VP.png')

#VISUAL PROGRAMMING
toolbar.addCommand('VP/Combine/Add', 'nuke.createNode("ma_Add")', '')
toolbar.addCommand('VP/Combine/Atop', 'nuke.createNode("ma_Atop")', '')
toolbar.addCommand('VP/Combine/Average', 'nuke.createNode("ma_Average")', '')
toolbar.addCommand('VP/Combine/Divide', 'nuke.createNode("ma_Divide")', '')
toolbar.addCommand('VP/Combine/Inside', 'nuke.createNode("ma_Inside")', '')
toolbar.addCommand('VP/Combine/Maximum', 'nuke.createNode("ma_Maximum")', '')
toolbar.addCommand('VP/Combine/Minimum', 'nuke.createNode("ma_Minimum")', '')
toolbar.addCommand('VP/Combine/Mix', 'nuke.createNode("ma_Mix")', '')
toolbar.addCommand('VP/Combine/Multiply', 'nuke.createNode("ma_Multiply")', '')
toolbar.addCommand('VP/Combine/Operator', 'nuke.createNode("ma_Operator")', '')
toolbar.addCommand('VP/Combine/Outside', 'nuke.createNode("ma_Outside")', '')
toolbar.addCommand('VP/Combine/Over', 'nuke.createNode("ma_Over")', '')
toolbar.addCommand('VP/Combine/Screen', 'nuke.createNode("ma_Screen")', '')
toolbar.addCommand('VP/Combine/Subtract', 'nuke.createNode("ma_Subtract")', '')
toolbar.addCommand('VP/Combine/SubtractAbs', 'nuke.createNode("ma_SubtractAbs")', '')

toolbar.addCommand('VP/Convert/Degree To Radian', 'nuke.createNode("ma_DegreeToRadian")', '')
toolbar.addCommand('VP/Convert/Float To Vector', 'nuke.createNode("ma_FloatToVector")', '')
toolbar.addCommand('VP/Convert/HSV to RGB', 'nuke.createNode("ma_HSVtoRGB")', '')
toolbar.addCommand('VP/Convert/Luminance', 'nuke.createNode("ma_Luminance")', '')
toolbar.addCommand('VP/Convert/Radian To Degree', 'nuke.createNode("ma_RadianToDegree")', '')
toolbar.addCommand('VP/Convert/RGB to HSV', 'nuke.createNode("ma_RGBtoHSV")', '')
toolbar.addCommand('VP/Convert/Vector To Float', 'nuke.createNode("ma_VectorToFloat")', '')

toolbar.addCommand('VP/Generic/Absolute', 'nuke.createNode("ma_Absolute")', '')
toolbar.addCommand('VP/Generic/ArcTangent', 'nuke.createNode("ma_ArcTangent")', '')
toolbar.addCommand('VP/Generic/Add Channel', 'nuke.createNode("ma_AddChannel")', '')
toolbar.addCommand('VP/Generic/Ceiling', 'nuke.createNode("ma_Ceiling")', '')
toolbar.addCommand('VP/Generic/Clamp', 'nuke.createNode("ma_Clamp2")', '')
toolbar.addCommand('VP/Generic/Compress', 'nuke.createNode("ma_Compress2")', '')
toolbar.addCommand('VP/Generic/Expand', 'nuke.createNode("ma_Expand2")', '')
toolbar.addCommand('VP/Generic/Exponential', 'nuke.createNode("ma_Exponent")', '')
toolbar.addCommand('VP/Generic/Falloff', 'nuke.createNode("ma_Falloff")', '')
toolbar.addCommand('VP/Generic/FitRange', 'nuke.createNode("ma_FitRange")', '')
toolbar.addCommand('VP/Generic/Floor', 'nuke.createNode("ma_Floor")', '')
toolbar.addCommand('VP/Generic/Fraction', 'nuke.createNode("ma_Fraction")', '')
toolbar.addCommand('VP/Generic/Function', 'nuke.createNode("ma_Function")', '')
toolbar.addCommand('VP/Generic/Hypotenuse', 'nuke.createNode("ma_Hypot")', '')
toolbar.addCommand('VP/Generic/toInt', 'nuke.createNode("ma_toInt")', '')
toolbar.addCommand('VP/Generic/Lerp', 'nuke.createNode("ma_Lerp")', '')
toolbar.addCommand('VP/Generic/Modulo', 'nuke.createNode("ma_Modulo")', '')
toolbar.addCommand('VP/Generic/Negate', 'nuke.createNode("ma_Negate")', '')
toolbar.addCommand('VP/Generic/pi', 'nuke.createNode("ma_pi")', '')
toolbar.addCommand('VP/Generic/Power', 'nuke.createNode("ma_Power")', '')
toolbar.addCommand('VP/Generic/ScanSlice', 'nuke.createNode("ma_ScanSlice")', '')
toolbar.addCommand('VP/Generic/Sign', 'nuke.createNode("ma_Sign")', '')
toolbar.addCommand('VP/Generic/Slice', 'nuke.createNode("ma_Slice")', '')
toolbar.addCommand('VP/Generic/Smoothstep', 'nuke.createNode("ma_Smoothstep")', '')
toolbar.addCommand('VP/Generic/Spike', 'nuke.createNode("ma_Spike")', '')
toolbar.addCommand('VP/Generic/Square Root', 'nuke.createNode("ma_SquareRoot")', '')
toolbar.addCommand('VP/Generic/Step', 'nuke.createNode("ma_Step")', '')

toolbar.addCommand('VP/Globals/BoundingBox', 'nuke.createNode("gl_BoundingBox")', '')
toolbar.addCommand('VP/Globals/CenterXY', 'nuke.createNode("gl_CenterXY")', '')
toolbar.addCommand('VP/Globals/Frame', 'nuke.createNode("gl_Frame")', '')
toolbar.addCommand('VP/Globals/FrameRange', 'nuke.createNode("gl_FrameRange")', '')
toolbar.addCommand('VP/Globals/Pixel Aspect', 'nuke.createNode("gl_PixelAspect")', '')
toolbar.addCommand('VP/Globals/Resolution', 'nuke.createNode("gl_Resolution")', '')
toolbar.addCommand('VP/Globals/RGB', 'nuke.createNode("gl_RGB")', '')
toolbar.addCommand('VP/Globals/SetupVP', 'nuke.createNode("gl_SetupVP")', '')
toolbar.addCommand('VP/Globals/UV', 'nuke.createNode("ma_UV")', '')
toolbar.addCommand('VP/Globals/XY', 'nuke.createNode("gl_XY")', '')

toolbar.addCommand('VP/Patterns/fBm', 'nuke.createNode("ma_fBm")', '')
#toolbar.addCommand('VP/Patterns/Grad', 'nuke.createNode("ma_Grad")', '')
toolbar.addCommand('VP/Patterns/Noise', 'nuke.createNode("ma_Noise")', '')
toolbar.addCommand('VP/Patterns/Oscillation', 'nuke.createNode("ma_Oscillation")', '')
toolbar.addCommand('VP/Patterns/Radial Grad', 'nuke.createNode("ma_RadialGrad")', '')
toolbar.addCommand('VP/Patterns/Rainbow', 'nuke.createNode("ma_Rainbow")', '')
toolbar.addCommand('VP/Patterns/Random', 'nuke.createNode("ma_Random")', '')
toolbar.addCommand('VP/Patterns/Shape', 'nuke.createNode("ma_Shape")', '')
toolbar.addCommand('VP/Patterns/Turbulence', 'nuke.createNode("ma_turbulence")', '')
toolbar.addCommand('VP/Patterns/Zoneplate', 'nuke.createNode("ma_Zoneplate")', '')

toolbar.addCommand('VP/Tools/Bytes', 'nuke.createNode("ma_Bytes")', '')
toolbar.addCommand('VP/Tools/Check Channel', 'nuke.createNode("ma_CheckChannel")', '')
toolbar.addCommand('VP/Tools/EdgeReplicate', 'nuke.createNode("ma_EdgeReplicate")', '')
toolbar.addCommand('VP/Tools/Null', 'nuke.createNode("ma_Null")', '')
toolbar.addCommand('VP/Tools/Pixel', 'nuke.createNode("to_Pixel2")', '')
toolbar.addCommand('VP/Tools/Point', 'nuke.createNode("ma_Point")', '')
toolbar.addCommand('VP/Tools/Sample', 'nuke.createNode("ma_Sample")', '')
toolbar.addCommand('VP/Tools/ScanLine', 'nuke.createNode("ma_ScanLine")', '')
toolbar.addCommand('VP/Tools/Set BBOX Color', 'nuke.createNode("ma_SetBBOXColor")', '')

toolbar.addCommand('VP/Transform/Rotate', 'nuke.createNode("ma_Rotate")', '')
toolbar.addCommand('VP/Transform/Scale', 'nuke.createNode("ma_Scale")', '')
toolbar.addCommand('VP/Transform/Translate', 'nuke.createNode("ma_Translate")', '')

toolbar.addCommand('VP/UV/Scale UV', 'nuke.createNode("ma_ScaleUV")', '')
toolbar.addCommand('VP/UV/Tile UV', 'nuke.createNode("ma_TileUV")', '')
toolbar.addCommand('VP/UV/Translate UV', 'nuke.createNode("ma_TranslateUV")', '')

toolbar.addCommand('VP/Vector/Cross Product', 'nuke.createNode("ma_CrossProduct")', '')
toolbar.addCommand('VP/Vector/Distance', 'nuke.createNode("ma_Distance")', '')
toolbar.addCommand('VP/Vector/Dot Product', 'nuke.createNode("ma_DotProduct")', '')
toolbar.addCommand('VP/Vector/Facing Ratio', 'nuke.createNode("td_FacingRatio")', '')
toolbar.addCommand('VP/Vector/Length', 'nuke.createNode("ma_Length")', '')
toolbar.addCommand('VP/Vector/Normalize', 'nuke.createNode("ma_Normalize")', '')
toolbar.addCommand('VP/Vector/Vector', 'nuke.createNode("ma_Vector")', '')

toolbar.addCommand('VP/Workflow/Add Constant', 'nuke.createNode("ma_AddConstant")', '')
toolbar.addCommand('VP/Workflow/And', 'nuke.createNode("ma_And")', '')
toolbar.addCommand('VP/Workflow/Condition', 'nuke.createNode("ma_Condition")', '')
toolbar.addCommand('VP/Workflow/Constant', 'nuke.createNode("ma_Constant")', '')
toolbar.addCommand('VP/Workflow/Copy Aspect Ratio', 'nuke.createNode("ma_CopyAspectRatio")', '')
toolbar.addCommand('VP/Workflow/Copy bbox', 'nuke.createNode("ma_CopyBBOX")', '')
toolbar.addCommand('VP/Workflow/Copy Frame Range', 'nuke.createNode("ma_CopyFrameRange")', '')
toolbar.addCommand('VP/Workflow/Copy Resolution', 'nuke.createNode("ma_CopyResolution")', '')
toolbar.addCommand('VP/Workflow/Divide Constant', 'nuke.createNode("ma_DivideConstant")', '')
toolbar.addCommand('VP/Workflow/Int', 'nuke.createNode("ma_Int")', '')
toolbar.addCommand('VP/Workflow/Multiply Constant', 'nuke.createNode("ma_MultiplyConstant")', '')
toolbar.addCommand('VP/Workflow/Not', 'nuke.createNode("ma_Not")', '')
toolbar.addCommand('VP/Workflow/Or', 'nuke.createNode("ma_Or")', '')
toolbar.addCommand('VP/Workflow/Two Way Switch', 'nuke.createNode("ma_TwoWaySwitch")', '')

import nuke
nuke.pluginAddPath("BL")

toolbar = nuke.menu('Nodes')
toolbar.addMenu('BL', 'BL.png')

#IMAGE
toolbar.addCommand('BL/Image/Arc', 'nuke.createNode("bl_Arc")', '')
toolbar.addCommand('BL/Image/Line', 'nuke.createNode("bl_Line")', '')
toolbar.addCommand('BL/Image/Random', 'nuke.createNode("bl_Random")', '')
toolbar.addCommand('BL/Image/Shape', 'nuke.createNode("bl_Shape")', '')
toolbar.addCommand('BL/Image/Star', 'nuke.createNode("bl_Star")', '')

#TIME
toolbar.addCommand('BL/Time/ITime', 'nuke.createNode("bl_ITime")', '')

#CHANNEL
toolbar.addCommand('BL/Channel/ChannelBox', 'nuke.createNode("bl_ChannelBox")', '')

#COLOR
toolbar.addCommand('BL/Color/Bytes', 'nuke.createNode("bl_Bytes")', '')
toolbar.addCommand('BL/Color/Compress', 'nuke.createNode("bl_Compress")', '')
toolbar.addCommand('BL/Color/Expand', 'nuke.createNode("bl_Expand")', '')
toolbar.addCommand('BL/Color/Monochrome', 'nuke.createNode("bl_Monochrome")', '')
toolbar.addCommand('BL/Color/Normalizer', 'nuke.createNode("bl_Normalizer")', '')
toolbar.addCommand('BL/Color/SaturationRGB', 'nuke.createNode("bl_SaturationRGB")', '')
toolbar.addCommand('BL/Color/Slice', 'nuke.createNode("bl_Slice")', '')
toolbar.addCommand('BL/Color/Threshold', 'nuke.createNode("bl_Threshold")', '')

#KEYER
toolbar.addCommand('BL/Keyer/ColorSupress', 'nuke.createNode("bl_ColorSupress")', '')
toolbar.addCommand('BL/Keyer/Despillator', 'nuke.createNode("bl_Despillator")', '')
toolbar.addCommand('BL/Keyer/HSV Keyer', 'nuke.createNode("bl_HSVKeyer")', '')
toolbar.addCommand('BL/Keyer/Simple Spill Supress', 'nuke.createNode("bl_SpillSupress")', '')

#LAYER
toolbar.addCommand('BL/Layer/LayerAE', 'nuke.createNode("bl_LayerAE")', '')

#FILTER
toolbar.addCommand('BL/Filter/Morphological/Binary', 'nuke.createNode("bl_mf_Binary")', '')
toolbar.addCommand('BL/Filter/Morphological/Border', 'nuke.createNode("bl_mf_Border")', '')
toolbar.addCommand('BL/Filter/Morphological/DirectionalBlur', 'nuke.createNode("bl_mf_DirectionalBlur")', '')
toolbar.addCommand('BL/Filter/Morphological/Occlusion', 'nuke.createNode("bl_mf_Occlusion")', '')
toolbar.addCommand('BL/Filter/Morphological/ShapeSofter', 'nuke.createNode("bl_mf_ShapeSofter")', '')

toolbar.addCommand('BL/Filter/BlurChroma', 'nuke.createNode("bl_BlurChroma")', '')
toolbar.addCommand('BL/Filter/Bokeh', 'nuke.createNode("bl_Bokeh")', '')
toolbar.addCommand('BL/Filter/IBokeh', 'nuke.createNode("bl_IBokeh")', '')
toolbar.addCommand('BL/Filter/ColorEdge', 'nuke.createNode("bl_ColorEdge")', '')
toolbar.addCommand('BL/Filter/Convolve', 'nuke.createNode("bl_Convolve")', '')
toolbar.addCommand('BL/Filter/CurveFilter', 'nuke.createNode("bl_CurveFilter")', '')
toolbar.addCommand('BL/Filter/EdgeExtend', 'nuke.createNode("bl_EdgeExtend2")', '')
toolbar.addCommand('BL/Filter/Emboss', 'nuke.createNode("bl_Emboss")', '')
toolbar.addCommand('BL/Filter/IBlur', 'nuke.createNode("bl_IBlur")', '')
toolbar.addCommand('BL/Filter/IDilateErode', 'nuke.createNode("bl_IDilateErode")', '')

#STYLISE
toolbar.addCommand('BL/Stylise/Mosaic', 'nuke.createNode("bl_Mosaic")', '')
toolbar.addCommand('BL/Stylise/Randomizer', 'nuke.createNode("bl_Randomizer")', '')
toolbar.addCommand('BL/Stylise/ScanLines', 'nuke.createNode("bl_ScanLines")', '')
toolbar.addCommand('BL/Stylise/Scatterize', 'nuke.createNode("bl_Scatterize")', '')
toolbar.addCommand('BL/Stylise/Solarize', 'nuke.createNode("bl_Solarize")', '')
toolbar.addCommand('BL/Stylise/TileMosaic', 'nuke.createNode("bl_TileMosaic")', '')
toolbar.addCommand('BL/Stylise/Zebrafy', 'nuke.createNode("bl_Zebrafy")', '')

#TRANSFORM
toolbar.addCommand('BL/Transform/Scroll', 'nuke.createNode("bl_Scroll")', '')
toolbar.addCommand('BL/Transform/ToBBOX', 'nuke.createNode("bl_ToBBOX")', '')

#WARP
toolbar.addCommand('BL/Warp/Bulge', 'nuke.createNode("bl_Bulge")', '')
toolbar.addCommand('BL/Warp/ChromaticAberation', 'nuke.createNode("bl_ChromaticAberation")', '')
toolbar.addCommand('BL/Warp/IDisplace', 'nuke.createNode("bl_IDisplace")', '')
toolbar.addCommand('BL/Warp/Twirl', 'nuke.createNode("bl_Twirl")', '')
toolbar.addCommand('BL/Warp/Wave', 'nuke.createNode("bl_Wave")', '')

#PIPE
toolbar.addCommand('BL/Pipe/GUI Switch', 'nuke.createNode("bl_GUISwitch")', '')
toolbar.addCommand('BL/Pipe/CleanOUT', 'nuke.createNode("bl_CleanOUT")', '')

#OTHER
toolbar.addCommand('BL/Other/Filler', 'nuke.createNode("bl_Filler")', '')
toolbar.addCommand('BL/Other/Match', 'nuke.createNode("bl_Match")', '')
toolbar.addCommand('BL/Other/Sample', 'nuke.createNode("bl_Sample")', '')
toolbar.addCommand('BL/Other/Scanner', 'nuke.createNode("bl_Scanner")', '')
toolbar.addCommand('BL/Other/ScanSlice', 'nuke.createNode("bl_ScanSlice")', '')
toolbar.addCommand('BL/Other/SetBBOXColor', 'nuke.createNode("bl_SetBBOXColor")', '')

#import autoCrop
#scripts_m = nuke.menu('Nuke').addMenu('Scripts')
#scripts_m.addCommand('Auto Crop', 'autoCrop.autoCrop()')


#import os
import sys
import nuke

# AP definitions

toolbar = nuke.menu('Nodes')

#AMenu = toolbar.addMenu('AP', icon='AP.png')

#AMenu.addCommand('A_Glow', 'nuke.createNode("A_glow")', icon='AP.png')
#nuke.menu('Nodes').addCommand('Filter/Halation', 'nuke.createNode("Halation")')

#toolbar = nuke.toolbar("Nodes")
#toolbar.addCommand("GlowLight", "nuke.createNode('GlowLight')", icon="GlowLight.png")

#HP Tools
toolbar = nuke.toolbar("Nodes")
nMajor = nuke.NUKE_VERSION_MAJOR
nMinor = nuke.NUKE_VERSION_MINOR
if nMajor == 12 and nMinor <= 1:
    m = toolbar.addMenu("HP Tools", icon="hpLogo.png")
    m.addCommand("NukeGLSL", lambda: nuke.createNode('NukeGLSL'), icon="hpLogo.png")

 
