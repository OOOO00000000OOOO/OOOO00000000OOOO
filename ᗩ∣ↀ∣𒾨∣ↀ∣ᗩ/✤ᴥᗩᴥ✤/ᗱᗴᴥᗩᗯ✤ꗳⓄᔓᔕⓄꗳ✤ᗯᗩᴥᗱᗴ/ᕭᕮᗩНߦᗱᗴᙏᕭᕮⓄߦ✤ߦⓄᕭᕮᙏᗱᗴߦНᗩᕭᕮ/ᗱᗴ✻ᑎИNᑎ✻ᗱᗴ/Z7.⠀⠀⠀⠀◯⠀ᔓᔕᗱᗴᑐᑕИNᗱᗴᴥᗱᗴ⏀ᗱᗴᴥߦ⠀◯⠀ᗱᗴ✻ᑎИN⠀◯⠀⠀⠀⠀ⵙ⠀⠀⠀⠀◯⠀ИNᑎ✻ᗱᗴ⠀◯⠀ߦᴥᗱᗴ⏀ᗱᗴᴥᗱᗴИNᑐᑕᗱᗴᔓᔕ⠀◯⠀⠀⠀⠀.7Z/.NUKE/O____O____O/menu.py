import sys
import nuke
import os
import webbrowser

#*****************************************************************
#*****************************************************************
#******************ADD THIS TO YOUR FILE INIT.PY******************
#O____O____O = "/Users/yourPath/.nuke/O____O____O"
#nuke.pluginAddPath(O____O____O)
#*****************************************************************
#*****************************************************************



toolbar = nuke.toolbar("Nodes")
m = toolbar.addMenu("O", icon = os.path.join(O____O____O, "icon/GNP.FCX.O____652_4_TNEIDARG_NOITCEJORP_ELCRIC____O____CIRCLE_PROJECTION_GRADIENT_4_256____O.XCF.PNG"))

m.addMenu( 'Creations', icon = os.path.join(O____O____O, "icon/01.png") )
m.addMenu( 'Alpha', icon = os.path.join(O____O____O, "icon/02.png") )
m.addMenu( 'Pixel', icon = os.path.join(O____O____O, "icon/03.png") )
m.addMenu( 'Keying and Despill', icon = os.path.join(O____O____O, "icon/04.png") )
m.addMenu( 'Transform', icon = os.path.join(O____O____O, "icon/05.png") )
m.addMenu( '3D and Deep', icon = os.path.join(O____O____O, "icon/06.png") )



#CREATIONS
m.addCommand('Creations/Random/Random Colors', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Creations/Random/Random_colors.nk") + "\")")
m.addCommand('Creations/Random/Random every Frame', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Creations/Random/Random_every_frame.nk") + "\")")
m.addCommand('Creations/Random/Random every Pixel', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Creations/Random/Random_every_pixel.nk") + "\")")
m.addCommand('Creations/Noise/Noise', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Creations/Noise/Noise.nk") + "\")")
m.addCommand('Creations/Noise/fBm', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Creations/Noise/fBm.nk") + "\")")
m.addCommand('Creations/Noise/Turbulence', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Creations/Noise/turbulence.nk") + "\")")
m.addCommand('Creations/lines vertical', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Creations/Lines_Vertical.nk") + "\")")
m.addCommand('Creations/lines horizontal', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Creations/Lines_Horizontal.nk") + "\")")
m.addCommand('Creations/lines vertical animated', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Creations/Lines_Vertical_Animated.nk") + "\")")
m.addCommand('Creations/lines horizontal animated', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Creations/Lines_Horizontal_Animated.nk") + "\")")
m.addCommand('Creations/circles', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Creations/circles.nk") + "\")")
m.addCommand('Creations/circles user', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Creations/circles_user.nk") + "\")")
m.addCommand('Creations/points', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Creations/points.nk") + "\")")
m.addCommand('Creations/points advanced', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Creations/points_advanced.nk") + "\")")
m.addCommand('Creations/bricks', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Creations/bricks.nk") + "\")")
m.addCommand('Creations/gradient horizontal', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Creations/gradient_horizontal.nk") + "\")")
m.addCommand('Creations/gradient horizontal invert', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Creations/gradient_horizontal_invert.nk") + "\")")
m.addCommand('Creations/gradient vertical', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Creations/gradient_vertical.nk") + "\")")
m.addCommand('Creations/gradient vertical invert', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Creations/gradient_vertical_invert.nk") + "\")")
m.addCommand('Creations/gradient 4 corners', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Creations/GradientCorner.nk") + "\")")
m.addCommand('Creations/radial', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Creations/radial.nk") + "\")")
m.addCommand('Creations/radial gradient', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Creations/radial_gradient.nk") + "\")")
m.addCommand('Creations/radial rays', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Creations/radial_rays.nk") + "\")")
m.addCommand('Creations/Trunc', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Creations/Trunc.nk") + "\")")



#ALPHA
m.addCommand('Alpha/alpha binary', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Alpha/alpha_binary.nk") + "\")")
m.addCommand('Alpha/alpha comparison', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Alpha/alpha_comparison.nk") + "\")")
m.addCommand('Alpha/alpha exists?', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Alpha/alpha_exists.nk") + "\")")
m.addCommand('Alpha/alpha sum', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Alpha/alpha_sum.nk") + "\")")



#PIXEL
m.addCommand('Pixel/absolute value', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Pixel/abs.nk") + "\")")
m.addCommand('Pixel/check negative', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Pixel/check_negative.nk") + "\")")
m.addCommand('Pixel/check nan inf pixels', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Pixel/check_nan_inf.nk") + "\")")
m.addCommand('Pixel/create nan pixel', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Pixel/create_nan.nk") + "\")")
m.addCommand('Pixel/kill nan pixel', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Pixel/kill_nan.nk") + "\")")
m.addCommand('Pixel/create inf pixel', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Pixel/create_inf.nk") + "\")")
m.addCommand('Pixel/kill inf pixel', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Pixel/kill_inf.nk") + "\")")



#TRANSFORM
m.addCommand('Transform/Coordinates', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Transform/coordinates.nk") + "\")")
m.addCommand('Transform/UV Map', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Transform/UV_map.nk") + "\")")
m.addCommand('Transform/UV to Vector', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Transform/UV_to_Vector.nk") + "\")")
m.addCommand('Transform/Vector to UV', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Transform/Vector_to_UV.nk") + "\")")
m.addCommand('Transform/transform', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Transform/transform.nk") + "\")")
m.addCommand('Transform/transform advanced', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Transform/transform_advanced.nk") + "\")")
m.addCommand('Transform/twist', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Transform/twist.nk") + "\")")
m.addCommand('Transform/STMap_invert', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Transform/STMap_invert.nk") + "\")")





#3D and DEEP
m.addCommand('3D and Deep/Normal Pass - Relight', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Deep_3D/normalPass_relight.nk") + "\")")
m.addCommand('3D and Deep/C4x4', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Deep_3D/C4x4.nk") + "\")")
m.addCommand('3D and Deep/Deep Thickness', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Deep_3D/deepThickness.nk") + "\")")
m.addCommand('3D and Deep/Deep to Depth', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Deep_3D/deepToDepth.nk") + "\")")
m.addCommand('3D and Deep/Deep from Depth', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Deep_3D/deepFromDepth.nk") + "\")")
m.addCommand('3D and Deep/Depth normalize', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Deep_3D/depth_normalize.nk") + "\")")



#KEYING and DESPILL
m.addCommand('Keying and Despill/despill green', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Keying_Despill/despill_green.nk") + "\")")
m.addCommand('Keying and Despill/despill green list', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Keying_Despill/despill_green_list.nk") + "\")")
m.addCommand('Keying and Despill/despill blue', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Keying_Despill/despill_blue.nk") + "\")")
m.addCommand('Keying and Despill/despill blue list', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Keying_Despill/despill_blue_list.nk") + "\")")
m.addCommand('Keying and Despill/keying', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Keying_Despill/keying.nk") + "\")")
m.addCommand('Keying and Despill/differenceKey', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Keying_Despill/differenceKey.nk") + "\")")
m.addCommand('Keying and Despill/IBKGizmo_Expression', "nuke.nodePaste(\"" + os.path.join(O____O____O + "/Keying_Despill/IBKGizmo_Expression.nk") + "\")")

m.addSeparator()


#INFO
m.addCommand('Info e Tutorial', "nuke.tcl('start', 'http://www.andreageremia.it/tutorial_expression_node.html')", icon = os.path.join(O____O____O, "icon/question_mark.png"))
